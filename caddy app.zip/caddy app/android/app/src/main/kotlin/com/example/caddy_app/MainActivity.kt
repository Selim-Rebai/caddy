package com.example.caddy_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
