import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:share_plus/share_plus.dart';
import 'firebase_options.dart';
import 'screens/home_screen.dart';
import 'screens/history_screen.dart';
import 'providers/shopping_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialiser Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const ProviderScope(child: CaddyApp()));
}

class CaddyApp extends StatelessWidget {
  const CaddyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Caddy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        primaryColor: const Color(0xFF4DD4AC),
        scaffoldBackgroundColor: const Color(0xFFF8FFFE),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF2D5E5E),
          elevation: 0,
          centerTitle: true,
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFF4DD4AC),
          foregroundColor: Colors.white,
        ),
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF4DD4AC),
          secondary: Color(0xFF2D5E5E),
        ),
      ),
      home: const MainNavigator(),
    );
  }
}

class MainNavigator extends ConsumerWidget {
  const MainNavigator({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final shoppingState = ref.watch(shoppingProvider);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'Caddy',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2D5E5E),
            ),
          ),
          actions: [
            // Indicateur de synchronisation
            if (shoppingState.isLoading)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF4DD4AC)),
                    ),
                  ),
                ),
              ),

            // 📤 BOUTON DE PARTAGE
            IconButton(
              icon: const Icon(
                Icons.share,
                color: Color(0xFF2D5E5E),
              ),
              onPressed: () {
                final shareText = ref.read(shoppingProvider.notifier).generateShareText();
                if (shareText.isNotEmpty) {
                  Share.share(shareText);
                } else {
                  // Message si pas d'articles à partager
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Ajoutez des articles à votre liste pour la partager !'),
                      duration: Duration(seconds: 2),
                    ),
                  );
                }
              },
              tooltip: 'Partager la liste',
            ),

            // Bouton mode courses
            IconButton(
              icon: Icon(
                shoppingState.isShoppingMode
                    ? Icons.shopping_cart
                    : Icons.shopping_cart_outlined,
                color: shoppingState.isShoppingMode
                    ? const Color(0xFF4DD4AC)
                    : const Color(0xFF2D5E5E),
              ),
              onPressed: () {
                ref.read(shoppingProvider.notifier).toggleShoppingMode();
              },
              tooltip: shoppingState.isShoppingMode
                  ? 'Quitter mode courses'
                  : 'Mode courses',
            ),

            // Menu avec options
            PopupMenuButton<String>(
              icon: const Icon(
                Icons.more_vert,
                color: Color(0xFF2D5E5E),
              ),
              onSelected: (value) async {
                switch (value) {
                  case 'new_list':
                    await ref.read(shoppingProvider.notifier).createNewList();
                    break;
                  case 'clear_completed':
                    await ref.read(shoppingProvider.notifier).clearCompletedItems();
                    break;
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'new_list',
                  child: Row(
                    children: [
                      Icon(Icons.add, size: 20),
                      SizedBox(width: 8),
                      Text('Nouvelle liste'),
                    ],
                  ),
                ),
                if (shoppingState.currentList != null &&
                    shoppingState.currentList!.completedItemsList.isNotEmpty)
                  const PopupMenuItem(
                    value: 'clear_completed',
                    child: Row(
                      children: [
                        Icon(Icons.clear_all, size: 20),
                        SizedBox(width: 8),
                        Text('Vider articles achetés'),
                      ],
                    ),
                  ),
              ],
            ),
          ],
          bottom: const TabBar(
            indicatorColor: Color(0xFF4DD4AC),
            labelColor: Color(0xFF2D5E5E),
            unselectedLabelColor: Color(0xFF9E9E9E),
            tabs: [
              Tab(
                icon: Icon(Icons.list_alt),
                text: 'Liste actuelle',
              ),
              Tab(
                icon: Icon(Icons.history),
                text: 'Historique',
              ),
            ],
          ),
        ),
        body: Column(
          children: [
            // Affichage des erreurs
            if (shoppingState.error != null)
              Container(
                width: double.infinity,
                color: Colors.red.shade50,
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.error_outline, color: Colors.red.shade700),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        shoppingState.error!,
                        style: TextStyle(color: Colors.red.shade700),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        ref.read(shoppingProvider.notifier).clearError();
                      },
                    ),
                  ],
                ),
              ),

            // Corps principal avec les onglets
            const Expanded(
              child: TabBarView(
                children: [
                  HomeScreen(),
                  HistoryScreen(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}