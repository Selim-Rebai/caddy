import 'package:cloud_firestore/cloud_firestore.dart';

class ShoppingItem {
  final String id;
  final String name;
  final String category;
  final bool isCompleted;
  final DateTime addedAt;

  ShoppingItem({
    required this.id,
    required this.name,
    required this.category,
    this.isCompleted = false,
    required this.addedAt,
  });

  ShoppingItem copyWith({
    String? id,
    String? name,
    String? category,
    bool? isCompleted,
    DateTime? addedAt,
  }) {
    return ShoppingItem(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      isCompleted: isCompleted ?? this.isCompleted,
      addedAt: addedAt ?? this.addedAt,
    );
  }

  // Conversion vers Map pour Firebase
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'isCompleted': isCompleted,
      'addedAt': Timestamp.fromDate(addedAt),
    };
  }

  // Création depuis Firebase
  factory ShoppingItem.fromJson(Map<String, dynamic> json) {
    return ShoppingItem(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      category: json['category'] ?? 'Autres',
      isCompleted: json['isCompleted'] ?? false,
      addedAt: json['addedAt'] is Timestamp
          ? (json['addedAt'] as Timestamp).toDate()
          : DateTime.parse(json['addedAt']),
    );
  }

  // Création depuis un document Firestore
  factory ShoppingItem.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ShoppingItem.fromJson({
      'id': doc.id,
      ...data,
    });
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is ShoppingItem &&
              runtimeType == other.runtimeType &&
              id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'ShoppingItem{id: $id, name: $name, category: $category, isCompleted: $isCompleted}';
  }
}