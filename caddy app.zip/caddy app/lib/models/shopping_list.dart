import 'package:cloud_firestore/cloud_firestore.dart';
import 'shopping_item.dart';

class ShoppingList {
  final String id;
  final String name;
  final List<ShoppingItem> items;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isActive;

  ShoppingList({
    required this.id,
    required this.name,
    required this.items,
    required this.createdAt,
    required this.updatedAt,
    this.isActive = false,
  });

  ShoppingList copyWith({
    String? id,
    String? name,
    List<ShoppingItem>? items,
    DateTime? createdAt,
    DateTime? updatedAt,
    bool? isActive,
  }) {
    return ShoppingList(
      id: id ?? this.id,
      name: name ?? this.name,
      items: items ?? this.items,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isActive: isActive ?? this.isActive,
    );
  }

  // Conversion vers Map pour Firebase
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'items': items.map((item) => item.toJson()).toList(),
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
      'isActive': isActive,
    };
  }

  // Création depuis Firebase
  factory ShoppingList.fromJson(Map<String, dynamic> json, {String? id}) {
    return ShoppingList(
      id: id ?? json['id'] ?? '',
      name: json['name'] ?? '',
      items: (json['items'] as List<dynamic>? ?? [])
          .map((item) => ShoppingItem.fromJson(item as Map<String, dynamic>))
          .toList(),
      createdAt: json['createdAt'] is Timestamp
          ? (json['createdAt'] as Timestamp).toDate()
          : DateTime.parse(json['createdAt']),
      updatedAt: json['updatedAt'] is Timestamp
          ? (json['updatedAt'] as Timestamp).toDate()
          : DateTime.parse(json['updatedAt']),
      isActive: json['isActive'] ?? false,
    );
  }

  // Création depuis un document Firestore
  factory ShoppingList.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ShoppingList.fromJson(data, id: doc.id);
  }

  // Méthodes utiles
  int get totalItems => items.length;

  int get completedItems => items.where((item) => item.isCompleted).length;

  int get pendingItemsCount => items.where((item) => !item.isCompleted).length;

  double get completionPercentage =>
      totalItems == 0 ? 0 : completedItems / totalItems;

  List<ShoppingItem> get pendingItems =>
      items.where((item) => !item.isCompleted).toList();

  List<ShoppingItem> get completedItemsList =>
      items.where((item) => item.isCompleted).toList();

  bool get isEmpty => items.isEmpty;

  bool get isCompleted => totalItems > 0 && completedItems == totalItems;

  // Formatage de la date pour l'affichage
  String get formattedDate {
    final now = DateTime.now();
    final difference = now.difference(createdAt).inDays;

    if (difference == 0) {
      return 'Aujourd\'hui';
    } else if (difference == 1) {
      return 'Hier';
    } else if (difference < 7) {
      return 'Il y a $difference jours';
    } else {
      return '${createdAt.day}/${createdAt.month}/${createdAt.year}';
    }
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is ShoppingList &&
              runtimeType == other.runtimeType &&
              id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() {
    return 'ShoppingList{id: $id, name: $name, items: ${items.length}, isActive: $isActive}';
  }
}