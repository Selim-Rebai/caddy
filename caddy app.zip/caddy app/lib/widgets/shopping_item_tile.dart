import 'package:flutter/material.dart';
import '../models/shopping_item.dart';

class ShoppingItemTile extends StatelessWidget {
  final ShoppingItem item;
  final bool isShoppingMode;
  final VoidCallback onToggle;
  final VoidCallback onRemove;

  const ShoppingItemTile({
    super.key,
    required this.item,
    required this.isShoppingMode,
    required this.onToggle,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(item.id),
      direction: DismissDirection.endToStart,
      confirmDismiss: (direction) async {
        return await _showDeleteConfirmation(context);
      },
      onDismissed: (direction) => onRemove(),
      background: Container(
        color: Colors.red,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 16),
        child: const Icon(
          Icons.delete,
          color: Colors.white,
          size: 24,
        ),
      ),
      child: InkWell(
        onTap: onToggle,
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: 16,
            vertical: isShoppingMode ? 20 : 16,
          ),
          child: Row(
            children: [
              // Checkbox (plus grande en mode courses)
              GestureDetector(
                onTap: onToggle,
                child: Container(
                  width: isShoppingMode ? 32 : 24,
                  height: isShoppingMode ? 32 : 24,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: item.isCompleted
                          ? const Color(0xFF4DD4AC)
                          : Colors.grey.shade400,
                      width: 2,
                    ),
                    color: item.isCompleted
                        ? const Color(0xFF4DD4AC)
                        : Colors.transparent,
                  ),
                  child: item.isCompleted
                      ? Icon(
                    Icons.check,
                    color: Colors.white,
                    size: isShoppingMode ? 20 : 16,
                  )
                      : null,
                ),
              ),

              SizedBox(width: isShoppingMode ? 16 : 12),

              // Nom de l'article
              Expanded(
                child: Text(
                  item.name,
                  style: TextStyle(
                    fontSize: isShoppingMode ? 18 : 16,
                    fontWeight: isShoppingMode ? FontWeight.w500 : FontWeight.normal,
                    decoration: item.isCompleted
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
                    color: item.isCompleted
                        ? Colors.grey.shade500
                        : const Color(0xFF2D5E5E),
                  ),
                ),
              ),

              // Actions (seulement si pas en mode courses)
              if (!isShoppingMode) ...[
                const SizedBox(width: 8),

                // Bouton de suppression
                GestureDetector(
                  onTap: () async {
                    final confirmed = await _showDeleteConfirmation(context);
                    if (confirmed == true) {
                      onRemove();
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      Icons.delete_outline,
                      color: Colors.grey.shade400,
                      size: 20,
                    ),
                  ),
                ),
              ],

              // Indicateur de temps (uniquement en mode normal)
              if (!isShoppingMode && !item.isCompleted) ...[
                const SizedBox(width: 8),
                _buildTimeIndicator(),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTimeIndicator() {
    final now = DateTime.now();
    final difference = now.difference(item.addedAt);

    String timeText;
    Color timeColor;

    if (difference.inMinutes < 1) {
      timeText = 'À l\'instant';
      timeColor = const Color(0xFF4DD4AC);
    } else if (difference.inHours < 1) {
      timeText = '${difference.inMinutes}m';
      timeColor = Colors.orange;
    } else if (difference.inDays < 1) {
      timeText = '${difference.inHours}h';
      timeColor = Colors.grey;
    } else {
      timeText = '${difference.inDays}j';
      timeColor = Colors.grey.shade400;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: timeColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        timeText,
        style: TextStyle(
          fontSize: 10,
          color: timeColor,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Future<bool?> _showDeleteConfirmation(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Supprimer l\'article'),
        content: Text('Voulez-vous supprimer "${item.name}" de votre liste ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );
  }
}