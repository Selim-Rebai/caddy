import 'package:flutter/material.dart';
import '../models/shopping_item.dart';
import 'shopping_item_tile.dart';

class CategorySection extends StatelessWidget {
  final String category;
  final List<ShoppingItem> items;
  final bool isExpanded;
  final bool isShoppingMode;
  final VoidCallback onToggleExpanded;
  final Function(String itemId) onToggleItem;
  final Function(String itemId) onRemoveItem;

  const CategorySection({
    super.key,
    required this.category,
    required this.items,
    required this.isExpanded,
    required this.isShoppingMode,
    required this.onToggleExpanded,
    required this.onToggleItem,
    required this.onRemoveItem,
  });

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Fruits/Légumes':
        return Icons.local_grocery_store;
      case 'Viande/Poisson':
        return Icons.set_meal;
      case 'Produits laitiers':
        return Icons.local_drink;
      case 'Épicerie':
        return Icons.shopping_basket;
      case 'Boissons':
        return Icons.local_bar;
      case 'Hygiène':
        return Icons.soap;
      case 'Maison':
        return Icons.home;
      default:
        return Icons.category;
    }
  }

  Color _getCategoryColor(String category) {
    switch (category) {
      case 'Fruits/Légumes':
        return Colors.green;
      case 'Viande/Poisson':
        return Colors.red;
      case 'Produits laitiers':
        return Colors.blue;
      case 'Épicerie':
        return Colors.orange;
      case 'Boissons':
        return Colors.purple;
      case 'Hygiène':
        return Colors.teal;
      case 'Maison':
        return Colors.brown;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    final completedItems = items.where((item) => item.isCompleted).length;
    final categoryColor = _getCategoryColor(category);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          // En-tête de catégorie
          InkWell(
            onTap: onToggleExpanded,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Icône de catégorie
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: categoryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      _getCategoryIcon(category),
                      color: categoryColor,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Nom de la catégorie
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          category,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          '$completedItems / ${items.length} articles',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Indicateur de progression
                  if (items.isNotEmpty) ...[
                    SizedBox(
                      width: 40,
                      height: 4,
                      child: LinearProgressIndicator(
                        value: completedItems / items.length,
                        backgroundColor: Colors.grey.shade200,
                        valueColor: AlwaysStoppedAnimation<Color>(categoryColor),
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],

                  // Icône d'expansion
                  Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                    color: Colors.grey.shade600,
                  ),
                ],
              ),
            ),
          ),

          // Liste des articles (si expanded)
          if (isExpanded && items.isNotEmpty)
            Column(
              children: [
                Container(
                  height: 1,
                  color: Colors.grey.shade200,
                ),
                ...items.asMap().entries.map((entry) {
                  final index = entry.key;
                  final item = entry.value;

                  return Column(
                    children: [
                      ShoppingItemTile(
                        item: item,
                        isShoppingMode: isShoppingMode,
                        onToggle: () => onToggleItem(item.id),
                        onRemove: () => onRemoveItem(item.id),
                      ),
                      if (index < items.length - 1)
                        Container(
                          height: 1,
                          margin: const EdgeInsets.only(left: 16),
                          color: Colors.grey.shade100,
                        ),
                    ],
                  );
                }),
              ],
            ),

          // Message si catégorie vide et en mode courses
          if (isExpanded && items.isEmpty && isShoppingMode)
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle_outline,
                    color: Colors.grey.shade400,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Aucun article dans cette catégorie',
                    style: TextStyle(
                      color: Colors.grey.shade500,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}