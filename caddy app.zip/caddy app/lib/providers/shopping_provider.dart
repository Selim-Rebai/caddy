import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../models/shopping_item.dart';
import '../models/shopping_list.dart';

// Provider principal
final shoppingProvider = StateNotifierProvider<ShoppingNotifier, ShoppingState>((ref) {
  return ShoppingNotifier();
});

// État de l'application
class ShoppingState {
  final List<ShoppingList> allLists;
  final ShoppingList? currentList;
  final bool isShoppingMode;
  final bool isLoading;
  final bool isInitialized;
  final Map<String, bool> expandedCategories;
  final String? error;

  ShoppingState({
    this.allLists = const [],
    this.currentList,
    this.isShoppingMode = false,
    this.isLoading = false,
    this.isInitialized = false,
    this.expandedCategories = const {},
    this.error,
  });

  ShoppingState copyWith({
    List<ShoppingList>? allLists,
    ShoppingList? currentList,
    bool? isShoppingMode,
    bool? isLoading,
    bool? isInitialized,
    Map<String, bool>? expandedCategories,
    String? error,
  }) {
    return ShoppingState(
      allLists: allLists ?? this.allLists,
      currentList: currentList ?? this.currentList,
      isShoppingMode: isShoppingMode ?? this.isShoppingMode,
      isLoading: isLoading ?? this.isLoading,
      isInitialized: isInitialized ?? this.isInitialized,
      expandedCategories: expandedCategories ?? this.expandedCategories,
      error: error,
    );
  }
}

class ShoppingNotifier extends StateNotifier<ShoppingState> {
  ShoppingNotifier() : super(ShoppingState()) {
    _initializeExpandedCategories();
    _initializeFirestore();
  }

  final _uuid = const Uuid();
  final _firestore = FirebaseFirestore.instance;

  // Catégories prédéfinies
  static const List<String> defaultCategories = [
    'Fruits/Légumes',
    'Viande/Poisson',
    'Produits laitiers',
    'Épicerie',
    'Boissons',
    'Hygiène',
    'Maison',
    'Autres'
  ];

  // Mapper les émojis par catégorie
  static const Map<String, String> categoryEmojis = {
    'Fruits/Légumes': '🍎',
    'Viande/Poisson': '🥩',
    'Produits laitiers': '🥛',
    'Épicerie': '🛒',
    'Boissons': '🥤',
    'Hygiène': '🧼',
    'Maison': '🏠',
    'Autres': '📦',
  };

  // Générer le texte de partage formaté
  String generateShareText() {
    if (state.currentList == null) return '';

    final currentList = state.currentList!;
    final pendingItems = currentList.pendingItems; // Articles non-achetés

    if (pendingItems.isEmpty) return '';

    final StringBuffer text = StringBuffer();

    // En-tête
    text.writeln('📋 ${currentList.name}');
    text.writeln('');

    // Grouper les articles par catégorie
    final Map<String, List<ShoppingItem>> pendingByCategory = {};

    for (final category in defaultCategories) {
      pendingByCategory[category] = [];
    }

    for (final item in pendingItems) {
      final category = item.category;
      if (pendingByCategory.containsKey(category)) {
        pendingByCategory[category]!.add(item);
      } else {
        pendingByCategory['Autres'] ??= [];
        pendingByCategory['Autres']!.add(item);
      }
    }

    // Supprimer les catégories vides
    pendingByCategory.removeWhere((key, value) => value.isEmpty);

    // Formatter chaque catégorie
    for (final entry in pendingByCategory.entries) {
      final category = entry.key;
      final items = entry.value;

      if (items.isNotEmpty) {
        final emoji = categoryEmojis[category] ?? '📦';
        text.writeln('$emoji $category:');

        for (final item in items) {
          text.writeln('• ${item.name}');
        }
        text.writeln('');
      }
    }

    // Signature
    text.writeln('📱 Envoyé depuis Caddy');

    return text.toString().trim();
  }


  void _initializeExpandedCategories() {
    final expanded = <String, bool>{};
    for (final category in defaultCategories) {
      expanded[category] = true;
    }
    state = state.copyWith(expandedCategories: expanded);
  }

  // Initialisation de Firestore avec listener en temps réel
  Future<void> _initializeFirestore() async {
    try {
      state = state.copyWith(isLoading: true, error: null);

      // Écouter les changements en temps réel
      _firestore
          .collection('shopping_lists')
          .orderBy('updatedAt', descending: true)
          .snapshots()
          .listen(
            (snapshot) {
          final lists = snapshot.docs
              .map((doc) => ShoppingList.fromFirestore(doc))
              .toList();

          final currentList = lists.where((list) => list.isActive).firstOrNull;

          state = state.copyWith(
            allLists: lists,
            currentList: currentList,
            isLoading: false,
            isInitialized: true,
          );

          // Si aucune liste active et aucune liste existante, créer une nouvelle liste
          if (currentList == null && lists.isEmpty) {
            _createNewList();
          }
        },
        onError: (error) {
          state = state.copyWith(
            isLoading: false,
            error: 'Erreur de synchronisation: $error',
          );
        },
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        error: 'Erreur d\'initialisation: $e',
      );
    }
  }

  // Création d'une nouvelle liste
  Future<void> _createNewList() async {
    try {
      final now = DateTime.now();
      final newListId = _uuid.v4();

      final newList = ShoppingList(
        id: newListId,
        name: 'Liste de courses - ${now.day}/${now.month}/${now.year}',
        items: [],
        createdAt: now,
        updatedAt: now,
        isActive: true,
      );

      final batch = _firestore.batch();

      // Désactiver toutes les autres listes
      for (final list in state.allLists) {
        if (list.isActive) {
          batch.update(
            _firestore.collection('shopping_lists').doc(list.id),
            {
              'isActive': false,
              'updatedAt': FieldValue.serverTimestamp(),
            },
          );
        }
      }

      // Créer la nouvelle liste
      batch.set(
        _firestore.collection('shopping_lists').doc(newListId),
        newList.toJson(),
      );

      await batch.commit();
    } catch (e) {
      state = state.copyWith(error: 'Erreur de création: $e');
    }
  }

  // Ajout d'un article
  Future<void> addItem(String name, String category) async {
    try {
      if (state.currentList == null) {
        await _createNewList();
        return;
      }

      final trimmedName = name.trim();
      if (trimmedName.isEmpty) return;

      // Vérifier si l'article existe déjà
      final existingItem = state.currentList!.items.any(
            (item) => item.name.toLowerCase() == trimmedName.toLowerCase(),
      );

      if (existingItem) return;

      final newItem = ShoppingItem(
        id: _uuid.v4(),
        name: trimmedName,
        category: category,
        addedAt: DateTime.now(),
      );

      final updatedItems = [...state.currentList!.items, newItem];

      // Mise à jour dans Firebase
      await _firestore
          .collection('shopping_lists')
          .doc(state.currentList!.id)
          .update({
        'items': updatedItems.map((item) => item.toJson()).toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      state = state.copyWith(error: 'Erreur d\'ajout: $e');
    }
  }

  // Basculer l'état d'un article
  Future<void> toggleItem(String itemId) async {
    try {
      if (state.currentList == null) return;

      final updatedItems = state.currentList!.items.map((item) {
        if (item.id == itemId) {
          return item.copyWith(isCompleted: !item.isCompleted);
        }
        return item;
      }).toList();

      await _firestore
          .collection('shopping_lists')
          .doc(state.currentList!.id)
          .update({
        'items': updatedItems.map((item) => item.toJson()).toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      state = state.copyWith(error: 'Erreur de modification: $e');
    }
  }

  // Supprimer un article
  Future<void> removeItem(String itemId) async {
    try {
      if (state.currentList == null) return;

      final updatedItems = state.currentList!.items
          .where((item) => item.id != itemId)
          .toList();

      await _firestore
          .collection('shopping_lists')
          .doc(state.currentList!.id)
          .update({
        'items': updatedItems.map((item) => item.toJson()).toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      state = state.copyWith(error: 'Erreur de suppression: $e');
    }
  }

  // Basculer le mode courses
  void toggleShoppingMode() {
    state = state.copyWith(isShoppingMode: !state.isShoppingMode);
  }

  // Basculer l'expansion d'une catégorie
  void toggleCategory(String category) {
    final expanded = Map<String, bool>.from(state.expandedCategories);
    expanded[category] = !(expanded[category] ?? true);

    state = state.copyWith(expandedCategories: expanded);
  }

  // Charger une liste depuis l'historique
  Future<void> loadList(String listId) async {
    try {
      final batch = _firestore.batch();

      // Désactiver la liste actuelle
      if (state.currentList != null) {
        batch.update(
          _firestore.collection('shopping_lists').doc(state.currentList!.id),
          {
            'isActive': false,
            'updatedAt': FieldValue.serverTimestamp(),
          },
        );
      }

      // Activer la nouvelle liste
      batch.update(
        _firestore.collection('shopping_lists').doc(listId),
        {
          'isActive': true,
          'updatedAt': FieldValue.serverTimestamp(),
        },
      );

      await batch.commit();
    } catch (e) {
      state = state.copyWith(error: 'Erreur de chargement: $e');
    }
  }

  // Dupliquer une liste
  Future<void> duplicateList(String listId) async {
    try {
      final originalList = state.allLists.firstWhere(
            (list) => list.id == listId,
      );

      final newItems = originalList.items.map((item) =>
          ShoppingItem(
            id: _uuid.v4(),
            name: item.name,
            category: item.category,
            addedAt: DateTime.now(),
          )
      ).toList();

      final now = DateTime.now();
      final newListId = _uuid.v4();
      final newList = ShoppingList(
        id: newListId,
        name: 'Copie - ${originalList.name}',
        items: newItems,
        createdAt: now,
        updatedAt: now,
        isActive: true,
      );

      final batch = _firestore.batch();

      // Désactiver toutes les autres listes
      for (final list in state.allLists) {
        if (list.isActive) {
          batch.update(
            _firestore.collection('shopping_lists').doc(list.id),
            {
              'isActive': false,
              'updatedAt': FieldValue.serverTimestamp(),
            },
          );
        }
      }

      // Créer la nouvelle liste
      batch.set(
        _firestore.collection('shopping_lists').doc(newListId),
        newList.toJson(),
      );

      await batch.commit();
    } catch (e) {
      state = state.copyWith(error: 'Erreur de duplication: $e');
    }
  }

  // Supprimer une liste
  Future<void> deleteList(String listId) async {
    try {
      await _firestore.collection('shopping_lists').doc(listId).delete();

      // Si c'était la liste actuelle et qu'il reste d'autres listes,
      // activer la plus récente
      if (state.currentList?.id == listId) {
        final remainingLists = state.allLists
            .where((list) => list.id != listId)
            .toList();

        if (remainingLists.isNotEmpty) {
          await loadList(remainingLists.first.id);
        } else {
          // Plus de liste, en créer une nouvelle
          await _createNewList();
        }
      }
    } catch (e) {
      state = state.copyWith(error: 'Erreur de suppression: $e');
    }
  }

  // Créer une nouvelle liste manuellement
  Future<void> createNewList() async {
    await _createNewList();
  }

  // Effacer les erreurs
  void clearError() {
    state = state.copyWith(error: null);
  }

  // Obtenir des suggestions basées sur l'historique
  List<String> getSuggestions(String query) {
    if (query.length < 2) return [];

    final allItems = state.allLists
        .expand((list) => list.items)
        .map((item) => item.name)
        .toSet()
        .toList();

    return allItems
        .where((item) =>
    item.toLowerCase().contains(query.toLowerCase()) &&
        (state.currentList?.items.every((currentItem) =>
        currentItem.name.toLowerCase() != item.toLowerCase()) ?? true))
        .take(5)
        .toList();
  }

  // Obtenir les articles par catégorie
  Map<String, List<ShoppingItem>> getItemsByCategory() {
    if (state.currentList == null) return {};

    final Map<String, List<ShoppingItem>> itemsByCategory = {};

    for (final category in defaultCategories) {
      itemsByCategory[category] = [];
    }

    for (final item in state.currentList!.items) {
      final category = item.category;
      if (itemsByCategory.containsKey(category)) {
        itemsByCategory[category]!.add(item);
      } else {
        itemsByCategory['Autres'] ??= [];
        itemsByCategory['Autres']!.add(item);
      }
    }

    // Supprimer les catégories vides sauf en mode shopping
    if (!state.isShoppingMode) {
      itemsByCategory.removeWhere((key, value) => value.isEmpty);
    }

    return itemsByCategory;
  }

  // Vider la liste actuelle (marquer tous les articles comme achetés)
  Future<void> clearCompletedItems() async {
    try {
      if (state.currentList == null) return;

      final pendingItems = state.currentList!.items
          .where((item) => !item.isCompleted)
          .toList();

      await _firestore
          .collection('shopping_lists')
          .doc(state.currentList!.id)
          .update({
        'items': pendingItems.map((item) => item.toJson()).toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      state = state.copyWith(error: 'Erreur de nettoyage: $e');
    }
  }
}