import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/shopping_provider.dart';
import '../models/shopping_list.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final shoppingState = ref.watch(shoppingProvider);
    final shoppingNotifier = ref.read(shoppingProvider.notifier);

    // État de chargement initial
    if (!shoppingState.isInitialized && shoppingState.isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF4DD4AC)),
            ),
            SizedBox(height: 16),
            Text(
              'Chargement de l\'historique...',
              style: TextStyle(
                color: Color(0xFF2D5E5E),
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }

    final allLists = shoppingState.allLists;

    if (allLists.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.history,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 24),
            Text(
              'Aucun historique',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Vos listes de courses apparaîtront ici',
              style: TextStyle(
                color: Colors.grey.shade500,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async {
        // La synchronisation est automatique avec les listeners Firestore
        // Mais on peut forcer un refresh si nécessaire
      },
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: allLists.length,
        itemBuilder: (context, index) {
          final shoppingList = allLists[index];
          return _buildListTile(
            context,
            ref,
            shoppingList,
            shoppingNotifier,
            shoppingState,
          );
        },
      ),
    );
  }

  Widget _buildListTile(
      BuildContext context,
      WidgetRef ref,
      ShoppingList shoppingList,
      ShoppingNotifier shoppingNotifier,
      ShoppingState shoppingState,
      ) {
    final isActive = shoppingList.isActive;

    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: isActive
                ? const Color(0xFF4DD4AC)
                : Colors.grey.shade100,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            isActive ? Icons.shopping_cart : Icons.shopping_cart_outlined,
            color: isActive ? Colors.white : Colors.grey.shade600,
            size: 24,
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(
                shoppingList.name,
                style: TextStyle(
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  color: isActive
                      ? const Color(0xFF2D5E5E)
                      : Colors.grey.shade700,
                ),
              ),
            ),
            if (isActive)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF4DD4AC),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  'ACTIVE',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.schedule,
                  size: 14,
                  color: Colors.grey.shade500,
                ),
                const SizedBox(width: 4),
                Text(
                  shoppingList.formattedDate,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(
                  Icons.shopping_basket,
                  size: 14,
                  color: Colors.grey.shade500,
                ),
                const SizedBox(width: 4),
                Text(
                  '${shoppingList.completedItems}/${shoppingList.totalItems} articles',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade500,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: LinearProgressIndicator(
                    value: shoppingList.completionPercentage,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      shoppingList.isCompleted
                          ? Colors.green
                          : const Color(0xFF4DD4AC),
                    ),
                  ),
                ),
              ],
            ),
            if (shoppingList.totalItems > 0) ...[
              const SizedBox(height: 8),
              _buildItemsPreview(shoppingList),
            ],
          ],
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (value) async {
            switch (value) {
              case 'activate':
                await shoppingNotifier.loadList(shoppingList.id);
                break;
              case 'duplicate':
                await shoppingNotifier.duplicateList(shoppingList.id);
                break;
              case 'delete':
                _showDeleteConfirmation(context, shoppingList, shoppingNotifier);
                break;
            }
          },
          itemBuilder: (context) => [
            if (!isActive)
              const PopupMenuItem(
                value: 'activate',
                child: Row(
                  children: [
                    Icon(Icons.shopping_cart, size: 20),
                    SizedBox(width: 8),
                    Text('Activer cette liste'),
                  ],
                ),
              ),
            const PopupMenuItem(
              value: 'duplicate',
              child: Row(
                children: [
                  Icon(Icons.copy, size: 20),
                  SizedBox(width: 8),
                  Text('Dupliquer'),
                ],
              ),
            ),
            if (!isActive)
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, size: 20, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Supprimer', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
          ],
        ),
        onTap: isActive ? null : () async {
          await shoppingNotifier.loadList(shoppingList.id);
        },
      ),
    );
  }

  Widget _buildItemsPreview(ShoppingList shoppingList) {
    final previewItems = shoppingList.pendingItems.take(3).toList();

    if (previewItems.isEmpty) {
      return Text(
        '✅ Liste terminée',
        style: TextStyle(
          fontSize: 12,
          color: Colors.green.shade600,
          fontWeight: FontWeight.w500,
        ),
      );
    }

    return Wrap(
      spacing: 4,
      runSpacing: 2,
      children: [
        ...previewItems.map((item) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            item.name,
            style: TextStyle(
              fontSize: 10,
              color: Colors.grey.shade700,
            ),
          ),
        )),
        if (shoppingList.pendingItemsCount > 3)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: const Color(0xFF4DD4AC).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              '+${shoppingList.pendingItemsCount - 3}',
              style: const TextStyle(
                fontSize: 10,
                color: Color(0xFF4DD4AC),
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
      ],
    );
  }

  void _showDeleteConfirmation(
      BuildContext context,
      ShoppingList shoppingList,
      ShoppingNotifier shoppingNotifier,
      ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Supprimer la liste'),
        content: Text(
          'Êtes-vous sûr de vouloir supprimer "${shoppingList.name}" ?\n\nCette action est irréversible.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              await shoppingNotifier.deleteList(shoppingList.id);
            },
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Supprimer'),
          ),
        ],
      ),
    );
  }
}