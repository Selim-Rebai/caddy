import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/shopping_provider.dart';
import '../models/shopping_item.dart';
import '../models/shopping_list.dart';
import '../widgets/add_item_dialog.dart';
import '../widgets/category_section.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final shoppingState = ref.watch(shoppingProvider);
    final shoppingNotifier = ref.read(shoppingProvider.notifier);

    // État de chargement initial
    if (!shoppingState.isInitialized && shoppingState.isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF4DD4AC)),
            ),
            SizedBox(height: 16),
            Text(
              'Synchronisation...',
              style: TextStyle(
                color: Color(0xFF2D5E5E),
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }

    // Aucune liste actuelle
    if (shoppingState.currentList == null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.shopping_cart_outlined,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 24),
            Text(
              'Aucune liste de courses',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => shoppingNotifier.createNewList(),
              icon: const Icon(Icons.add),
              label: const Text('Créer une liste'),
            ),
          ],
        ),
      );
    }

    final currentList = shoppingState.currentList!;
    final itemsByCategory = shoppingNotifier.getItemsByCategory();

    return Scaffold(
      body: Column(
        children: [
          // En-tête avec informations sur la liste
          _buildListHeader(context, currentList, shoppingState),

          // Barre de recherche / Ajout rapide
          _buildSearchBar(context, ref),

          // Liste des articles par catégorie
          Expanded(
            child: itemsByCategory.isEmpty
                ? _buildEmptyState(context, ref)
                : _buildCategorizedList(context, ref, itemsByCategory, shoppingState),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddItemDialog(context, ref),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildListHeader(BuildContext context, ShoppingList currentList, ShoppingState shoppingState) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  currentList.name,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
              ),
              if (shoppingState.isShoppingMode)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF4DD4AC),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text(
                    'MODE COURSES',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                Icons.shopping_basket,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                '${currentList.completedItems} / ${currentList.totalItems} articles',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 14,
                ),
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.access_time,
                size: 16,
                color: Colors.grey.shade600,
              ),
              const SizedBox(width: 4),
              Text(
                currentList.formattedDate,
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          if (currentList.totalItems > 0) ...[
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: currentList.completionPercentage,
              backgroundColor: Colors.grey.shade200,
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF4DD4AC)),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context, WidgetRef ref) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: TextField(
        decoration: const InputDecoration(
          hintText: 'Ajouter un article...',
          prefixIcon: Icon(Icons.search),
          suffixIcon: Icon(Icons.add_circle_outline),
        ),
        onTap: () => _showAddItemDialog(context, ref),
        readOnly: true,
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context, WidgetRef ref) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.add_shopping_cart,
            size: 80,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 24),
          Text(
            'Votre liste est vide',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Ajoutez votre premier article pour commencer',
            style: TextStyle(
              color: Colors.grey.shade500,
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => _showAddItemDialog(context, ref),
            icon: const Icon(Icons.add),
            label: const Text('Ajouter un article'),
          ),
        ],
      ),
    );
  }

  Widget _buildCategorizedList(
      BuildContext context,
      WidgetRef ref,
      Map<String, List<ShoppingItem>> itemsByCategory,
      ShoppingState shoppingState,
      ) {
    // Convertir en liste pour éviter les problèmes de typage
    final categoryEntries = itemsByCategory.entries.toList();

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: categoryEntries.length,
      itemBuilder: (context, index) {
        final entry = categoryEntries[index];
        final category = entry.key;
        final items = entry.value;

        return CategorySection(
          category: category,
          items: items,
          isExpanded: shoppingState.expandedCategories[category] ?? true,
          isShoppingMode: shoppingState.isShoppingMode,
          onToggleExpanded: () {
            ref.read(shoppingProvider.notifier).toggleCategory(category);
          },
          onToggleItem: (itemId) {
            ref.read(shoppingProvider.notifier).toggleItem(itemId);
          },
          onRemoveItem: (itemId) {
            ref.read(shoppingProvider.notifier).removeItem(itemId);
          },
        );
      },
    );
  }

  void _showAddItemDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AddItemDialog(
        onAddItem: (name, category) {
          ref.read(shoppingProvider.notifier).addItem(name, category);
        },
        getSuggestions: (query) {
          return ref.read(shoppingProvider.notifier).getSuggestions(query);
        },
      ),
    );
  }
}